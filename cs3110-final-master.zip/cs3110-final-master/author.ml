let hours_worked = 75
